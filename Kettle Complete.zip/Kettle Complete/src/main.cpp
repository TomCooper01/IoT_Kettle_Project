#include <Arduino.h>

#include <ESPmDNS.h>
#include <WiFi.h>
#include <WiFiClient.h>
#include <WebServer.h>
#include <WebSocketsServer.h>

#include <iostream>
#include <cstring>
#include <string>

#include <Ticker.h>
#include <analogWrite.h>
#include <NewPing.h>
#include <Preferences.h>

#include "WiFi/index.h"

#define KETTLESWITCH 15

//#define WATERSWITCH

#define REDPIN 14
#define BLUEPIN 2
#define GREENPIN 12

#define RELAY 12

//  Echo Sensor for Mugs
#define TRIGGER_PIN   16
#define ECHO_PIN      4
#define MAX_DISTANCE 200
#define mugThrushold 5

//  Tempreature Readings
#define THERMISITORPIN            3
#define SERIEREISITOR         10000
#define THERMISTORNOMINAL      1100      
#define BCOEFFICIENT           3950
#define TEMPERATURENOMINAL       25   
#define MAX_VALUE              4096 //ESP32
#define r                         0.05f

//  Kettle cooldown
#define COOLDOWNTIME          100000.0f

float KETTLETARGETTEMPRATURE;
#define KETTLETEMPRATURETOLORANCE 1.5f

const char *targetTemprature = "TARGETTEMPRATURE";
const char *targetTime = "TARGETTIME";

byte queueCounter = 0;
#define readingQueueSize 4
int readingQueue[readingQueueSize];

//  Calibration time elapsed
unsigned long startTime;
unsigned long endTime;

//  Error Handling
float MAXHEATINGTIME;
#define MINIMUMTIME 30000.0f
#define TIMETOLORACE 5.0f

#define MINIMUMTEMPRATURE 35.0f

// Demo define will allow for Serial 
#define DEBUG 1

Ticker startTimer;
Ticker wifiCheckTimer;
Ticker ErrorTimeoutTimer;
Ticker onlineStartTimer;

unsigned long heatingTime;
unsigned long coolingTime;

//  Declare WebServers
WebServer server(80);
WebSocketsServer webSocket(81);

//  Global Variables
String networksDetected;
const char* softAPName = "Kettle";

Preferences WiFiCredentialsStorage;
Preferences KettleTargets;

//  Error Messages
String WiFiErrorMessage = "";
String errorMessage = "";

//  If the kettle is on with the switch no remote turn off.
bool kettleSwitchState = false;

NewPing sonar(TRIGGER_PIN, ECHO_PIN, MAX_DISTANCE);

/**
 * Forward Decleartion
 */

//  On button press change state
void onStartPressISR();

//  State Handling
void stateCheckHandle();
void calibrationIdle();
void calibrating();
void calibrationComplete();
void idleHandle();
void heatingHandle();
void preInitHandle();
void digitalStart();
void PreDigitalInit();
void onOnlineStartTimer();
void postInitHandle();
void postHeatingHandle();

//  Error Handling
void errorHandle();
void preErrorReset();
void errorReset();

//  Specific Errors
void errorMug();
void errorWater();
void errorHeating();

//  WiFi Handle
void WiFiSetupHandle();
void WiFiCredentialParse();
void WiFiCredentialCheck();
void WiFiErrorHandle();

//  Website Handle
void setupPage();
void homePage();
void debugPage();

//  WiFi Misc
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length);
void wifiCredentials(const char* property, const char* param);
String wifiScan();

//  Websocket Event and Server handle
void payloadConvert(char* payload, uint8_t num);
void doTheThing(char* property, uint8_t num);
void doTheThingWith(char* property, char* param, uint8_t num);

//  Misc
void onStartTimer();
void rgbHandle(byte red, byte green, byte blue);
bool mugDetection();

void onRisingSwitchCalibration();
void onFallingSwitchCalibration();

//  Temprature
void queueThermisitorReading();
int averageThermisitorReading();
const float_t getTemperaure();
void calibrationSet(const char* key, const float_t value);


enum KettleState  {
  STATE_CHECK,
  CALIBARATION_IDLE,
  CALIBRATING,
  CALIBRATION_COMPLETE,
  IDLE,
  PRE_INIT,
  PRE_ONLINE_INIT,
  POST_INIT,
  HEATING,
  POST_HEAT,
  ERROR,
  POST_ERROR
};

/*
  TODO: Locking of the kettle and ownership of the control
*/

void (*STATE_HANDLERS[])() = {
  &stateCheckHandle,
  &calibrationIdle,
  &calibrating,
  &calibrationComplete,
  &idleHandle,
  &preInitHandle,
  &PreDigitalInit,
  &postInitHandle,
  &heatingHandle,
  &postHeatingHandle,
  &errorHandle,
  &preErrorReset
};

KettleState state = STATE_CHECK;
KettleState previousState = STATE_CHECK;

void setup() {
  #ifdef DEBUG
  Serial.begin(115200);
  #endif

  pinMode(KETTLESWITCH, INPUT_PULLUP);  //  Kettle on/off Button

  #ifdef WATERSWITCH
  pinMode(WATERSWITCH, INPUT_PULLUP);   //  Water on/off
  #endif

  //  RGB LED
  pinMode(REDPIN, OUTPUT);
  pinMode(GREENPIN, OUTPUT);
  pinMode(BLUEPIN, OUTPUT);

  //  Relay Switch
  pinMode(RELAY, OUTPUT);

  //  Scan for avaiable WiFi Networks
  networksDetected = wifiScan();

  WiFiCredentialsStorage.begin("credentials", false);
  String SSID = WiFiCredentialsStorage.getString("SSID", ""); 
  WiFiCredentialsStorage.end();   

  if(SSID == "") {  
    WiFiSetupHandle();  
  }
  else { 
    WiFiCredentialParse();  
  }


  #ifdef DEBUG
    server.on("/debug", debugPage);
  #endif

  #ifdef DEBUG
    //  mDNS Setup "https://Kettle.local/"
    if (!MDNS.begin("kettle")) Serial.println("Error setting up MDNS responder!");
    else Serial.println("kettle.local");
  #else
    MDNS.begin("kettle");
  #endif

  //  Add service to MDNS-SD
  MDNS.addService("https", "tcp", 80);

  //  Starts WebServer and WebSocket
  server.begin();
  webSocket.begin();
  webSocket.onEvent(webSocketEvent);
}

void loop() {
  STATE_HANDLERS[state]();
  webSocket.loop();
  server.handleClient();

  if(!(WiFiErrorMessage == "")) WiFiErrorHandle();
  if(!(errorMessage == "")) 
  
  if(state != previousState)  {
    previousState = state;
    webSocket.broadcastTXT("STATE," + String(state));
  }

}

void WiFiSetupHandle()
{
  //  Start of the Soft Access Point
  #ifdef DEBUG
    Serial.println(WiFi.softAP(softAPName) ? "Ready" : "Failed!");
  #else
    WiFi.softAP(softAPName);
  #endif

  //  WiFi Setup Page
  server.on("/", setupPage);
}

void WiFiCredentialParse()
{
  WiFiCredentialsStorage.begin("credentials", false);
  String SSID = WiFiCredentialsStorage.getString("SSID", ""); 
  String PASSWORD = WiFiCredentialsStorage.getString("PASSWORD", "");
  WiFiCredentialsStorage.end();

  WiFi.mode(WIFI_STA);
  WiFi.begin(SSID.c_str(), PASSWORD.c_str());

  wifiCheckTimer.attach_ms(10000, WiFiCredentialCheck);
}

void WiFiCredentialCheck(){
  
  wifiCheckTimer.detach();

  if(WiFi.status() != WL_CONNECTED)
  {
    WiFiErrorMessage = "Credentials not found!";
    WiFiSetupHandle();
  }
  else{
    //espalexa.addDevice(alexaKettle);
    server.on("/", homePage);
  }
}

void WiFiErrorHandle()
{
  #ifdef DEBUG
    Serial.println(WiFiErrorMessage);
  #endif
  webSocket.broadcastTXT(WiFiErrorMessage);
  WiFiErrorMessage = "";
}

String wifiScan() {

  WiFi.mode(WIFI_STA);

  int wifiSize = WiFi.scanNetworks();

  WiFi.disconnect();

  String WiFiNetworks = "";

  if (wifiSize == 0) return strdup("");

  for (int i = 0; i < wifiSize; i++) {
    if(i == wifiSize-1) WiFiNetworks += WiFi.SSID(i);
    else WiFiNetworks += WiFi.SSID(i) + ",";
  }

  return WiFiNetworks;
}

void wifiCredentials(const char* property, const char* param)
{
  WiFiCredentialsStorage.begin("credentials", false);
  WiFiCredentialsStorage.putString(property, param);
  WiFiCredentialsStorage.end();
}

void setupPage()
{
  server.send(200, "text/html", WIFISETUP);
}

void homePage()
{
  server.send(200, "text/html", MAIN);
}

void debugPage()
{
  server.send(200, "text/html", DEBUGPAGE);
}

void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  switch (type) {
    case WStype_DISCONNECTED: {
        #ifdef DEBUG
        Serial.printf("[%u] Disconnected!\n", num);
        #endif
        break;
      }
    case WStype_CONNECTED: {
        IPAddress ip = webSocket.remoteIP(num);
        #ifdef DEBUG
          Serial.printf("[%u] Connected from %d.%d.%d.%d url: %s\n", num, ip[0], ip[1], ip[2], ip[3], payload);
        #endif

        // Send message to client
        webSocket.sendTXT(num, "Connected");
        webSocket.sendTXT(num, ("STATE," + String(state)));

        break;
      }
    case WStype_TEXT: {
        //  Convert payload to Char array
        payloadConvert((char*)payload, num);
        break;
      }
    case WStype_ERROR:
    case WStype_BIN:
    case WStype_PING:
    case WStype_PONG:
    case WStype_FRAGMENT_TEXT_START:
    case WStype_FRAGMENT_BIN_START:
    case WStype_FRAGMENT:
    case WStype_FRAGMENT_FIN:
    break;
  }
}

void payloadConvert(char* payload, uint8_t num){
  char* p = strchr(payload, ',');
  if(p) {
    *p='\0';
    p++;
    doTheThingWith(payload, p, num);
  }
  else
  {
    doTheThing(payload, num);
  }
}

void doTheThing(char* property, uint8_t num)
{
  if(strcmp(property, "WIFI") == 0){
    webSocket.sendTXT(num, "NETWORKS," + networksDetected);
  }
  else if(strcmp(property, "SWITCH") == 0){
    if(state == IDLE && !kettleSwitchState){
      state = PRE_INIT;
      Serial.println("WEB BUTTON PRESSED!");
      webSocket.broadcastTXT("STATE CHANGED!");
    }
    else if(state == IDLE && !kettleSwitchState){
      Serial.println("WEB BUTTON PRESSED! No activation switch already engaged");
      webSocket.broadcastTXT("Kettle is already on!");
    }
    else{
      webSocket.sendTXT(num, "Kettle in calibration part of setup. Please press the kettle button.");
    }
  }
  else if(strcmp(property, "RESET") == 0){
    WiFiCredentialsStorage.clear();
    wifiCredentials("SSID", "");
    wifiCredentials("PASSWORD", "");
    ESP.restart();
  }
  else if(strcmp(property, "FACTORY") == 0){
    WiFiCredentialsStorage.clear();
    KettleTargets.clear();
    wifiCredentials("SSID", "");
    wifiCredentials("PASSWORD", "");
    ESP.restart();
  }
  else if(strcmp(property, "Done") == 0){
    ESP.restart();
  }
}

void doTheThingWith(char* property, char* param, uint8_t num)
{
  if(strcmp(property, "AccessPointName") == 0){
    wifiCredentials("SSID", param);
    webSocket.sendTXT(num, "Access Point Name Saved");
  }
  else if(strcmp(property, "AccessPointPassword") == 0){
    wifiCredentials("PASSWORD", param);
    webSocket.sendTXT(num, "Access Point Password Saved");
  }
  else{
    webSocket.broadcastTXT("Property: " + String(property) + "| Param: " + param);
  }
}

void stateCheckHandle(){
  KettleTargets.begin("TARGETS", false);

  KETTLETARGETTEMPRATURE = KettleTargets.getFloat(targetTemprature, 0.0f);
  MAXHEATINGTIME = KettleTargets.getFloat(targetTime, 0.0f);

  KettleTargets.end();

  if((KETTLETARGETTEMPRATURE != 0 && KETTLETARGETTEMPRATURE > MINIMUMTEMPRATURE) || (MAXHEATINGTIME != 0 && MAXHEATINGTIME > MINIMUMTIME)){

    //  Reduce maxium heating temprature
    KETTLETARGETTEMPRATURE =- KETTLETEMPRATURETOLORANCE;

    //  Increase maxium heating time
    MAXHEATINGTIME += TIMETOLORACE;

    attachInterrupt(KETTLESWITCH, onStartPressISR, RISING);
    state = IDLE;
  }
  else{
    state = CALIBARATION_IDLE;
    attachInterrupt(KETTLESWITCH, onRisingSwitchCalibration, RISING);
  }
}

void idleHandle(){
  rgbHandle(0,255,255);
}

void onStartPressISR(){
  kettleSwitchState = true;
  state = PRE_INIT;
}

void preInitHandle(){
  startTimer.attach_ms(2000, onStartTimer);
  state = IDLE;
}

void onStartTimer(){
  startTimer.detach();
  state = POST_INIT;
}

//  Digital Press
void digitalStart(){
  state = PRE_ONLINE_INIT;
}

//  Different start timers depending on kettle input
void PreDigitalInit(){
  if(mugDetection()){
    onlineStartTimer.attach_ms(30000, onOnlineStartTimer);
  }
  else{
    onlineStartTimer.attach_ms(2000, onOnlineStartTimer);
  }
  
  #ifdef WATERSWITCH
  if(!digitalRead(WATERSWITCH)){
    onlineStartTimer.attach_ms(60000, onOnlineStartTimer);
  }
  #endif

  state = IDLE;
}

void onOnlineStartTimer(){
  onlineStartTimer.detach();
  state = POST_INIT;
}


bool sensible_checks(){
   if(!mugDetection()){
    errorMessage = "No Mug Present";
    state = ERROR;
    return false;
  }

  #ifdef WATERSWITCH
  if(!digitalRead(WATERSWITCH)){
    errorMessage = "No water in the kettle";
    state = ERROR;
    return false;
  }
  #endif

  return true;
}

void postInitHandle(){
  if (!sensible_checks()){
    return;
  }

  state = HEATING;
  rgbHandle(0,255,0);
  heatingTime = millis();
  digitalWrite(RELAY, HIGH);
}

void heatingHandle(){
  if (!sensible_checks()){
    return;
  }

  if(getTemperaure() >= KETTLETARGETTEMPRATURE){
    state = POST_HEAT;
    digitalWrite(RELAY, LOW);       //  Turn off the kettle
    detachInterrupt(KETTLESWITCH);  //  Turn off the switch controling the switch
    rgbHandle(255,128,0);
    coolingTime = millis();
    return;
  }
  else if(millis() - heatingTime > MAXHEATINGTIME){
    state = ERROR;
    errorMessage = "Heating too long somethings wrong!";
    return;
  }
  else{
    state = HEATING;
    digitalWrite(RELAY, HIGH);
    return;
  }
}

void postHeatingHandle(){
  if(millis() - coolingTime > COOLDOWNTIME){
    kettleSwitchState = false;
    state = IDLE;
    attachInterrupt(KETTLESWITCH, onStartPressISR, RISING);
  }
}

void onRisingSwitchCalibration() {
  startTime = millis();
  detachInterrupt(KETTLESWITCH);
  attachInterrupt(KETTLESWITCH, onFallingSwitchCalibration, FALLING);
  state = CALIBRATING;
}

void onFallingSwitchCalibration() {
  digitalWrite(RELAY, LOW);
  endTime = millis();
  detachInterrupt(KETTLESWITCH);
  state = CALIBRATION_COMPLETE;
}

void calibrationIdle() {
  rgbHandle(255, 215, 0);
}

void calibrating() {
  digitalWrite(RELAY, HIGH);
  getTemperaure();
}

void calibrationComplete() {
  detachInterrupt(KETTLESWITCH);
  attachInterrupt(KETTLESWITCH, onStartPressISR, RISING);
  calibrationSet(targetTemprature, getTemperaure());
  calibrationSet(targetTime, float(endTime - startTime));
  state = STATE_CHECK;
}


void calibrationSet(const char* key, const float_t value) {

  KettleTargets.begin("TARGETS", false);
  KettleTargets.putFloat(key, value);
  KettleTargets.end();

}

void errorHandle(){
  #ifdef DEBUG
    Serial.println(errorMessage);
  #endif

  webSocket.broadcastTXT("ERROR,"+ errorMessage);
  errorMessage.clear();
  digitalWrite(RELAY, LOW);
  rgbHandle(255,0,0);
  ErrorTimeoutTimer.attach_ms(10000, errorReset);
}

void preErrorReset(){
  //  Timeout
}

void errorReset(){
  ErrorTimeoutTimer.detach();
  state = STATE_CHECK;
}

void errorMug(){
  state = ERROR;
  errorMessage = "Mug Moved!";
}

void errorWater(){
  state = ERROR;
  errorMessage =  "No water in system!";
}

void queueThermisitorReading() {
  if (queueCounter >= 5) queueCounter = 0;

  readingQueue[queueCounter] = analogRead(THERMISITORPIN);

  queueCounter++;  
}

int averageThermisitorReading() {

  int sumOfReadings = 0;

  size_t n = sizeof(readingQueue) / sizeof(readingQueue[0]);

  for (byte i = 0; i < readingQueueSize; i++) {
    sumOfReadings += readingQueue[i];
  }
  
  return (sumOfReadings / n);
}

const float_t getTemperaure() {
  queueThermisitorReading();
  int rawReading = averageThermisitorReading();
  static float smoothedReading = rawReading;
  smoothedReading = rawReading * r + smoothedReading * (1.0f - r);
  float partial = log(SERIEREISITOR / (((MAX_VALUE / smoothedReading) - 1) * THERMISTORNOMINAL));
  return 1.0 / (partial / BCOEFFICIENT + 1.0 / (TEMPERATURENOMINAL + 273.15)) - 273.15;
}

/**
 * @brief Handles the RGB light in the top of the kettle
 * analogWrite is 0 to 255
 * @param redValue 
 * @param greenValue 
 * @param blueValue 
 */
void rgbHandle(byte redValue, byte greenValue, byte blueValue){

  byte red = 255 - redValue;
  byte green = 255 - greenValue;
  byte blue = 255 - blueValue;

  analogWrite(REDPIN, red);
  analogWrite(GREENPIN, green);
  analogWrite(BLUEPIN, blue);
}

bool mugDetection(){
  return (sonar.ping_cm() <= mugThrushold);
}

//Something for to use when I have yet to make a function
//void something(){}
